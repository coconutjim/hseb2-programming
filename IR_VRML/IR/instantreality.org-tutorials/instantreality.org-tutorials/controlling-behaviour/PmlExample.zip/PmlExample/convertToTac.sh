#!/bin/csh -f

#################################################################################
# This script can be used to convert X3D/HAnim-based animations given as ROUTEs #
# into TimedAnimationContainer nodes and test PML scripts as needed for the     #
# Behaviour Control Component.                                                  #
# The cshell script requires *nix systems or cygwin (including tools like bc)   #
# as well as having ...Instant Player/bin in the PATH.                          #
# It assumes that each input file contains one HAnim figure and one animation   #
# such as nod, wave hand, or a walk cycle. For example, if you have these three #
# files and the character's name shall be Joe, then simply call the script like #
# this: "./convertToTac.sh nod.wrl wave.wrl walk.wrl Joe"                       #
#################################################################################

if ($#argv == 0) then
	echo "Usage: $0 *.wrl CharacterName"
	exit 0
endif

set AVATAR=${argv[$#argv]}
echo "Creating TACs for $AVATAR..."

# do same step first for hanim to guarantee same joint configuration, 
# because first file is also used to create the static hanim figure
set TACNAME=`echo $1 | sed -e 's/\(.*\)\.wrl/\1/g'`
mkdir -p tacs
aopt -i $1 -u -O ${AVATAR} -A ${TACNAME}:1 -d Background -d AnimationContainer -v tacs/${AVATAR}.wrl


# script converts hanim+anim files to TAC+pml
echo "<definitions id='DEF_${AVATAR}'>" > def.pml
echo "  <character id='${AVATAR}' src='${AVATAR}.wrl' root='${AVATAR}_HUMANOID'>" >> def.pml

echo "<actions id='ACT_${AVATAR}' start='true'>" > act.pml
echo "  <character refId='${AVATAR}'>" >> act.pml

while ("$1" != "${AVATAR}")

    set TACNAME=`echo $1 | sed -e 's/\(.*\)\.wrl/\1/g'`
    set FILENAME=${TACNAME}"_TAC.wrl"
    
    aopt -i $1 -u -O ${AVATAR} -A ${TACNAME}:${AVATAR} -d Background -d HAnimHumanoid -v tacs/${FILENAME}
	
    set DURT=`grep cycleInterval $1 | sed -e 's/^.*cycleInterval\s*\(\b.*\b\)\s*.*$/\1/g'`
    set DUR=`echo "scale=0; 1000 * ${DURT} / 1;" | bc -l`

    echo "Processing file "$1" -> "${TACNAME}" -> "${FILENAME}" -> dur="${DUR}

    echo "    <multiPoses id='${AVATAR}_${TACNAME}' src='${FILENAME}' dur='${DUR}' />" >> def.pml

    echo "    <animate id='anim-${TACNAME}'>" >> act.pml
    echo "      <multiPoses refId='${AVATAR}_${TACNAME}' />" >> act.pml
    echo "    </animate>" >> act.pml

    echo "      <action refId='anim-${TACNAME}' begin='0' dur='${DUR}' />" >> tmp.pml
    
    shift
end

# special case Displacer: create interpolators
if ( -f morphDef.txt ) then
	cat morphDef.txt >> def.pml
	
	rm morphDef.txt
	mv *_MorphTAC.wrl tacs
endif

echo "  </character>" >> act.pml

echo "  <schedule>" >> act.pml
echo "    <seq>" >> act.pml

cat tmp.pml >> act.pml

echo "    </seq>" >> act.pml
echo "  </schedule>" >> act.pml

echo "</actions>" >> act.pml

echo "  </character>" >> def.pml
echo "</definitions>" >> def.pml

rm tmp.pml
mv *.pml tacs

The texture maps in this directory were downloaded from
www.texturez.com
Visit the page for licensing terms.

import vrml.*;
import vrml.node.*;
import vrml.field.*;

public class ScriptTemplate extends vrml.node.Script
{
  public void initialize()
  {
  }

  public void processEvents(int count, vrml.Event events[])
  {
  }

  public void processEvent(vrml.Event event)
  {
  }

  public void eventsProcessed()
  {
  }

  public void shutdown()
  {
  }
}

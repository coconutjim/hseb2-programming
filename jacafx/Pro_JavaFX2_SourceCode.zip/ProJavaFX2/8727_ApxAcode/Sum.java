// Sum.java
public interface Sum {
  int addInts(int a, int b);
  double addDoubles(double x, double y);
}
